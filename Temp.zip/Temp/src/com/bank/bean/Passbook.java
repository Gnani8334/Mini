package com.bank.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="passbook_db")
public class Passbook {
	@Id
	int accNumber;
	String TransactionDetails;

	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public String getTransactionDetails() {
		return TransactionDetails;
	}
	public void setTransactionDetails(String transactionDetails) {
		TransactionDetails = transactionDetails;
	}
	
	
}
