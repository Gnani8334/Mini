package com.bank.exceprtion;

public class CustomerNotFound extends Exception {
public CustomerNotFound(String s)
{
	super(s);
}

public CustomerNotFound()
{
	super();
}


public void getMessage(String string) {
	
	// TODO Auto-generated method stub
	System.out.println("Something Wrong!!!");
	
}

@Override
public String toString() {
	return "CustomerNotFound []";
}

}
