package com.bank.util;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class JPAUtil {


	public static EntityManager getEntityManager() {
		/*if(entityManager==null || !entityManager.isOpen()) {
			entityManager = factory.createEntityManager();
		}
		return entityManager;*/
		return Persistence.createEntityManagerFactory("Temp").createEntityManager();
	}
}
